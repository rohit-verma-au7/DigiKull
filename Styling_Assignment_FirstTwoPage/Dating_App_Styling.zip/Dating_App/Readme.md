Instructions
Forms are always an essential part of any project and you will be working with a lot of forms in most of the applications so why not practice it earlier and test your knowledge. Once you get familiar with the input field or basic tags in HTML to create a form make a project using all those tags. How to use a text field, checkbox, radio button, date, and other important elements in a single form. You will be learning how to give a proper structure to a webpage while creating a form.

Create an application For Permission To Date My Daughter/Son

It should have :

Personal Details

Name

Email

phone number (only numeric)

Gander:

Date of proposed outing

Check all that apply to you:

- I have tattoos and/or piercings

- I am more than 2 years older than my daughter

- I own a panel van or Ferrari

- I work full-time

- My parents are rich

- Is the date at a private/public location

Education level completed

Essay section:

Why do you want to date my daughter (50 words input)?

Please provide 1 contact point for your reference

An option to upload the bank statement :-)

A submit button
